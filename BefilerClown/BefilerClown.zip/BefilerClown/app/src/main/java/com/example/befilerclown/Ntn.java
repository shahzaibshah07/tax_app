package com.example.befilerclown;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Ntn extends AppCompatActivity {
    String user_id;
    String fullname;
    String cnic;
    String dob;
    String occupation;

   private Ntn(String user_id,String fullname, String cnic,String dob,String occupation){
       this.fullname=fullname;
       this.cnic=cnic;
       this.dob=dob;
       this.occupation=occupation;
   }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getCnic() {
        return cnic;
    }

    public void setCnic(String cnic) {
        this.cnic = cnic;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }
}