package com.example.befilerclown;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class efilling extends AppCompatActivity {
    private EditText inputFullname,inputCnic ,inputDob, inputOccupation;
    TextView btnContinue;
    private FirebaseDatabase mFirebaseDatabase;
    String userID;
    private ProgressDialog progressDialog;
    private FirebaseAuth auth;
    private DatabaseReference myRef;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        setContentView(R.layout.signup);
        final SharedPreferences sharedpreferences = getSharedPreferences("home", Context.MODE_PRIVATE);
        progressDialog = new ProgressDialog(efilling.this);
        progressDialog.setMessage("Please Wait");
        //Get Firebase auth instance
        auth = FirebaseAuth.getInstance();
        inputFullname = (EditText) findViewById(R.id.input_fullname);
        inputCnic = (EditText) findViewById(R.id.input_cnic);
        inputDob = (EditText) findViewById(R.id.input_dob);
        inputOccupation = (EditText) findViewById(R.id.input_occupation);


        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String fullname = inputFullname.getText().toString();
                final String cnic = inputCnic.getText().toString();
                final String dob = inputDob.getText().toString();
                final String occupation = inputOccupation.getText().toString();
                if (TextUtils.isEmpty(fullname)) {
                    Toast.makeText(getApplicationContext(), "Enter Fullname!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(cnic)) {
                    Toast.makeText(getApplicationContext(), "Enter Your CNIC No!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(dob)) {
                    Toast.makeText(getApplicationContext(), "Enter Date Of Birth!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(occupation)) {
                    Toast.makeText(getApplicationContext(), "Enter your Occupation!", Toast.LENGTH_SHORT).show();
                    return;
                }

                progressDialog.show();
                //create user
                auth.createUserWithEmailAndPassword(fullname, cnic)
                        .addOnCompleteListener(efilling.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                Toast.makeText(efilling.this, "createUserWithEmail:onComplete:" + task.isSuccessful(), Toast.LENGTH_SHORT).show();
                                progressDialog.dismiss();
                                // If sign in fails, display a message to the user. If sign in succeeds
                                // the auth state listener will be notified and logic to handle the
                                // signed in user can be handled in the listener.
                                if (!task.isSuccessful()) {
                                    Toast.makeText(efilling.this, "Registration failed." + task.getException(),
                                            Toast.LENGTH_SHORT).show();
                                } else {
                                    SharedPreferences.Editor editor = sharedpreferences.edit();
                                    editor.putString("fullname", inputFullname.getText().toString());
                                    editor.putString("cnic", inputCnic.getText().toString());
                                    editor.putString("dob", inputDob.getText().toString());
                                    editor.putString("occupation", inputOccupation.getText().toString());

                                    editor.putString("uid", auth.getCurrentUser().getUid());
                                    editor.apply();
                                    userID = auth.getCurrentUser().getUid();
                                    //  creatuser(auth.getCurrentUser().getUid(), inputFullname.getText().toString(), inputCnic.getText().toString(), inputDob.getText().toString(), inputOccupation.getText().toString());
                                    startActivity(new Intent(efilling.this, home.class));
                                    finish();
                                }
                            }
                        });
            }
        });
    }
}

