package com.example.befilerclown;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class home extends AppCompatActivity {
    ImageButton efilling_button, register_ntn, verify_ntn, btn_calculator, btn_faqs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        efilling_button=findViewById(R.id.btn_efilling);
        register_ntn = findViewById(R.id.btn_register);
        verify_ntn = findViewById(R.id.btn_verify);
        btn_calculator =findViewById(R.id.btn_calculator);

        btn_faqs = findViewById(R.id.btn_faqs);
        efilling_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(home.this, efilling.class);
                startActivity(i);
            }

        });
        register_ntn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(home.this, register_ntn.class);
                startActivity(i);
            }
        });
        verify_ntn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(home.this, verify_ntn.class);
                startActivity(i);
            }
        });
        btn_calculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(home.this, calculator.class);
            }
        });
        btn_faqs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(home.this, faqs.class);
            }
        });
    }
}

